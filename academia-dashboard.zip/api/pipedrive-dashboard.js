export default async function handler(req, res) {
  const token = process.env.PIPEDRIVE_API_TOKEN;

  const dealsRes = await fetch(
    `https://api.pipedrive.com/v1/deals?api_token=${token}`
  );
  const dealsData = await dealsRes.json();

  const deals = dealsData.data.map(d => ({
    id: d.id,
    title: d.title,
    owner_id: d.user_id?.value,
    pipeline: d.pipeline_id,
    stage: d.stage_id,
    status: d.status,
    value: d.value,
    expectedClose: d.expected_close_date,
    wonDate: d.won_time,
    hasNextActivity: !!d.next_activity_date,
  }));

  return new Response(JSON.stringify({
    deals,
    activities: [],
    elearning: null,
    updatedAt: new Date()
  }), {
    headers: { "Content-Type": "application/json" }
  });
}
